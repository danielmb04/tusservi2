<?php
include "conexion.php";

$usuario1 = $_GET['usuario1'];
$usuario2 = $_GET['usuario2'];

// Consulta para obtener todos los mensajes entre usuario1 y usuario2
$sql = "SELECT id, emisor_id, receptor_id, mensaje, fecha_envio, leido, tipo 
        FROM mensajes 
        WHERE (emisor_id = ? AND receptor_id = ?) OR (emisor_id = ? AND receptor_id = ?)
        ORDER BY fecha_envio ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iiii", $usuario1, $usuario2, $usuario2, $usuario1);
$stmt->execute();
$result = $stmt->get_result();

$mensajes = [];

while ($row = $result->fetch_assoc()) {
    $mensajes[] = $row;
}

// Marcar como leídos los mensajes que recibió usuario1 y que no estaban leídos aún
// (es decir, mensajes cuyo receptor_id = usuario1 y leido = FALSE)
$updateSql = "UPDATE mensajes SET leido = TRUE WHERE receptor_id = ? AND emisor_id = ? AND leido = FALSE";
$updateStmt = $conn->prepare($updateSql);
$updateStmt->bind_param("ii", $usuario1, $usuario2);
$updateStmt->execute();

echo json_encode($mensajes);
?>
