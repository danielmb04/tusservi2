<?php
include 'conexion.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

if (!isset($_GET['idEmpresa'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Parámetro idEmpresa no definido']);
    exit;
}

$idEmpresa = intval($_GET['idEmpresa']);

$sql = "SELECT * FROM servicios WHERE idEmpresaFK = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idEmpresa);
$stmt->execute();
$result = $stmt->get_result();

$servicios = array();

while ($fila = $result->fetch_assoc()) {
    $servicios[] = $fila;
}

$response = array(
    "success" => true,
    "servicios" => $servicios
);

echo json_encode($response);

$conn->close();
?>
