<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include 'conexion.php'; // archivo que conecta a tu BD

if (isset($_GET['idProfesional'])) {
    $idProfesional = intval($_GET['idProfesional']);

    $sql = "SELECT 
                u.nombreUsuario,
                u.emailUsuario,
                u.contraseñaUsuario,
                u.telefonoUsuario,
                u.direccionUsuario,
                u.ciudadUsuario,
                u.fotoPerfilUsuario,
                p.categoriaProfesional,
                p.experienciaProfesional,
		p.fotoPerfilProfesional
            FROM Usuarios u
            INNER JOIN Profesionales p ON u.idUsuario = p.idUsuarioFK
            WHERE p.idProfesional = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idProfesional);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($fila = $resultado->fetch_assoc()) {
        echo json_encode($fila);
    } else {
        echo json_encode(["error" => "Profesional no encontrado"]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["error" => "Falta idProfesional"]);
}
?>
