<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

$host = "localhost";
$db = "TusServiPrueba";
$user = "root"; // Cambia si usas otro usuario
$password = "studium2023;"; // Cambia si tienes contraseña

try {
    $conexion = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $password);
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $query = "
        SELECT 
            e.idEmpresa,
	    e.idProfesionalFK,
            e.nombreEmpresa,
            e.descripcionEmpresa,
            e.ubicacionEmpresa,
            e.horarioEmpresa,
            e.webEmpresa,
            e.logoEmpresa,
            p.categoriaProfesional,
	    p.experienciaProfesional
        FROM Empresas e
        INNER JOIN Profesionales p ON e.idProfesionalFK = p.idProfesional
        ORDER BY e.fechaRegistroEmpresa DESC
    ";

    $stmt = $conexion->prepare($query);
    $stmt->execute();

    $empresas = [];

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    // Si el campo 'logoEmpresa' no está vacío, se le antepone la URL base
    if (!empty($row["logoEmpresa"])) {
       $row["logoEmpresa"] = $row["logoEmpresa"];
    }
    $empresas[] = $row;
}


    echo json_encode(array("success" => true, "empresas" => $empresas));

} catch (PDOException $e) {
    echo json_encode(array("success" => false, "error" => "Error al procesar datos: " . $e->getMessage()));
}
?>
