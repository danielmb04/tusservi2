<?php
include 'conexion.php';

$idUsuario = $_GET['idUsuario'];

$sql = "SELECT u.nombreUsuario, p.fotoPerfilProfesional 
        FROM Usuarios u 
        JOIN Profesionales p ON u.idUsuario = p.idUsuarioFK 
        WHERE u.idUsuario = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idUsuario);
$stmt->execute();

$result = $stmt->get_result();
$data = $result->fetch_assoc();

// Añadir la URL completa de la imagen
$data['fotoPerfilProfesional'] = "http://10.0.2.2/TUSSERVI/uploads/" . $data['fotoPerfilProfesional'];

echo json_encode($data);
?>
