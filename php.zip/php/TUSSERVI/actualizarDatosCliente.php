<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include 'conexion.php';

$data = json_decode(file_get_contents("php://input"), true);

if ($data) {
    $idUsuario = $data['idUsuario'] ?? null;

    if ($idUsuario === null) {
        echo json_encode(["error" => "Falta idUsuario"]);
        exit;
    }

    // Obtener usuario y fotoPerfilUsuario actual
    $sql = "SELECT idUsuario, fotoPerfilUsuario FROM Usuarios WHERE idUsuario = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idUsuario);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $fotoPerfilUsuarioActual = $row['fotoPerfilUsuario']; // para conservar si no envían nueva imagen
    } else {
        echo json_encode(["error" => "Usuario no encontrado"]);
        exit;
    }
    $stmt->close();

    // Datos recibidos
    $nombre = $data['nombreUsuario'] ?? null;
    $email = $data['emailUsuario'] ?? null;
    $contrasena = $data['contraseñaUsuario'] ?? null;
    $telefono = $data['telefonoUsuario'] ?? null;
    $direccion = $data['direccionUsuario'] ?? null;
    $ciudad = $data['ciudadUsuario'] ?? null;
    $fotoPerfilUsuario = $data['fotoPerfilUsuario'] ?? null; // base64 o null

    // Procesar imagen base64 (si viene)
    if (!empty($fotoPerfilUsuario) && $fotoPerfilUsuario !== "null") {
        if (preg_match('/^data:image\/(\w+);base64,/', $fotoPerfilUsuario, $type)) {
            $fotoPerfilUsuario = substr($fotoPerfilUsuario, strpos($fotoPerfilUsuario, ',') + 1);
            $tipo = strtolower($type[1]);
            if (!in_array($tipo, ['jpg', 'jpeg', 'png', 'gif'])) {
                echo json_encode(["error" => "Tipo de imagen no soportado"]);
                exit;
            }
        } else {
            $tipo = 'jpg';
        }

        $fotoPerfilDecodificada = base64_decode($fotoPerfilUsuario);

        if ($fotoPerfilDecodificada === false) {
            echo json_encode(["error" => "Base64 no válido"]);
            exit;
        }

        $carpetaUploads = "uploads/";
        if (!file_exists($carpetaUploads)) {
            mkdir($carpetaUploads, 0755, true);
        }

        $nombreArchivo = "perfilUsuario_" . uniqid() . "." . $tipo;
        $rutaArchivo = $carpetaUploads . $nombreArchivo;

        if (file_put_contents($rutaArchivo, $fotoPerfilDecodificada) === false) {
            echo json_encode(["error" => "No se pudo guardar la imagen"]);
            exit;
        }

        // Borrar la foto anterior si existe
        if ($fotoPerfilUsuarioActual && file_exists($carpetaUploads . $fotoPerfilUsuarioActual)) {
            unlink($carpetaUploads . $fotoPerfilUsuarioActual);
        }

        $fotoPerfilParaBD = $carpetaUploads . $nombreArchivo;

    } else {
        $fotoPerfilParaBD = null; // no actualizar foto
    }

    // Actualizar Usuarios
    if ($fotoPerfilParaBD !== null) {
        // Con foto nueva
        $sqlUsuarios = "UPDATE Usuarios SET nombreUsuario=?, emailUsuario=?, contraseñaUsuario=?, telefonoUsuario=?, direccionUsuario=?, ciudadUsuario=?, fotoPerfilUsuario=? WHERE idUsuario=?";
        $stmt1 = $conn->prepare($sqlUsuarios);
        $stmt1->bind_param("sssssssi", $nombre, $email, $contrasena, $telefono, $direccion, $ciudad, $fotoPerfilParaBD, $idUsuario);
    } else {
        // Sin foto nueva (mantener la anterior)
        $sqlUsuarios = "UPDATE Usuarios SET nombreUsuario=?, emailUsuario=?, contraseñaUsuario=?, telefonoUsuario=?, direccionUsuario=?, ciudadUsuario=? WHERE idUsuario=?";
        $stmt1 = $conn->prepare($sqlUsuarios);
        $stmt1->bind_param("ssssssi", $nombre, $email, $contrasena, $telefono, $direccion, $ciudad, $idUsuario);
    }

    // Para debug (opcional, quita o comenta en producción)
    error_log("Datos para actualizar usuario $idUsuario: nombre=$nombre, email=$email, telefono=$telefono, direccion=$direccion, ciudad=$ciudad, fotoPerfil=" . ($fotoPerfilParaBD ?? 'sin cambio'));

    if ($stmt1->execute()) {
        if ($stmt1->affected_rows > 0) {
            echo json_encode(["success" => true, "message" => "Perfil actualizado correctamente"]);
        } else {
            echo json_encode(["success" => false, "message" => "No se actualizó ningún registro (posible que los datos sean iguales)"]);
        }
    } else {
        error_log("Error en consulta UPDATE: " . $stmt1->error);
        echo json_encode(["error" => "Error en la consulta: " . $stmt1->error]);
    }

    $stmt1->close();
    $conn->close();
} else {
    echo json_encode(["error" => "No se recibieron datos"]);
}
