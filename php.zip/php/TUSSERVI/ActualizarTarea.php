<?php
header('Content-Type: application/json');

include 'conexion.php';

$idTarea = $_POST['idTarea'] ?? null;
$descripcion = $_POST['descripcion'] ?? '';
$horaInicio = $_POST['horaInicio'] ?? '';
$horaFin = $_POST['horaFin'] ?? '';
$realizada = isset($_POST['realizada']) ? intval($_POST['realizada']) : 0;

if ($idTarea && $descripcion) {
    $stmt = $conn->prepare("UPDATE tareas SET descripcion = ?, realizada = ?, horaInicio = ?, horaFin = ? WHERE idTarea = ?");
    $stmt->bind_param("sissi", $descripcion, $realizada, $horaInicio, $horaFin, $idTarea);

    if ($stmt->execute()) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "error" => "Error al actualizar tarea"]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false, "error" => "Faltan parámetros"]);
}

$conn->close();
?>
