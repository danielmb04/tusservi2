// crear_tarea.php
include 'conexion.php'; // archivo con conexión a la base de datos

$idUsuario = $_POST['idUsuario'];
$descripcion = $_POST['descripcion'];

$sql = "INSERT INTO Tareas (idUsuario, descripcion) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $idUsuario, $descripcion);
if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "error" => $stmt->error]);
}
