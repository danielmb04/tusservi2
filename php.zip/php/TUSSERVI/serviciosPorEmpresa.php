<?php
header('Content-Type: application/json; charset=utf-8');
$conexion = new mysqli("localhost", "root", "studium2023;", "TusServiPrueba");

if ($conexion->connect_error) {
    die(json_encode(["success" => false, "message" => "Error de conexión: " . $conexion->connect_error]));
}

$idEmpresa = isset($_GET['id']) ? intval($_GET['id']) : 0;

$sql = "SELECT 
            s.idServicio,
            s.tituloServicio AS titulo,
            s.descripcionServicio,
            s.precioEstimadoServicio AS precio,
            s.fechaPublicacionServicio AS fecha,
            p.categoriaProfesional AS categoria,
            p.ubicacionProfesional AS ubicacion,
            p.idProfesional,
            u.nombreUsuario AS profesional,
            u.ciudadUsuario AS ciudad,
            IFNULL(ROUND(AVG(v.puntuacionValoracion),1), 0) AS valoracion
        FROM Servicios s
        JOIN Empresas e ON s.idEmpresaFK = e.idEmpresa
        JOIN Profesionales p ON e.idProfesionalFK = p.idProfesional
        JOIN Usuarios u ON p.idUsuarioFK = u.idUsuario
        LEFT JOIN Valoraciones v ON p.idProfesional = v.idProfesionalFK
        WHERE s.idEmpresaFK = $idEmpresa
        GROUP BY s.idServicio
        ORDER BY s.fechaPublicacionServicio DESC";

$resultado = $conexion->query($sql);
$servicios = [];

if ($resultado && $resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        $servicios[] = $fila;
    }
    echo json_encode(["success" => true, "servicios" => $servicios]);
} else {
    echo json_encode(["success" => false, "message" => "No hay servicios para esta empresa"]);
}

$conexion->close();
?>
