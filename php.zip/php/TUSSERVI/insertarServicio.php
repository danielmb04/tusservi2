<?php
header("Content-Type: application/json");
include("conexion.php"); // Tu conexión a la BD

// Recoger datos del cuerpo POST en formato JSON
$datos = json_decode(file_get_contents("php://input"), true);

if(isset($datos["idEmpresaFK"], $datos["tituloServicio"], $datos["descripcionServicio"], $datos["precioEstimadoServicio"])) {
    $idEmpresaFK = $datos["idEmpresaFK"];
    $titulo = $datos["tituloServicio"];
    $descripcion = $datos["descripcionServicio"];
    $precio = $datos["precioEstimadoServicio"];

    $query = "INSERT INTO Servicios (idEmpresaFK, tituloServicio, descripcionServicio, precioEstimadoServicio)
              VALUES (?, ?, ?, ?)";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("issd", $idEmpresaFK, $titulo, $descripcion, $precio);

    if($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Servicio insertado"]);
    } else {
        echo json_encode(["success" => false, "message" => "Error al insertar"]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false, "message" => "Datos incompletos"]);
}

$conn->close();
?>
