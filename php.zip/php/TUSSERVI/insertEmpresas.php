<?php
header("Content-Type: application/json");

$conexion = new mysqli("localhost", "root", "studium2023;", "TusServiPrueba");
if ($conexion->connect_error) {
    echo json_encode(["success" => false, "message" => "Error de conexión"]);
    exit;
}

$idProfesional = $_POST["idProfesional"];
$nombre = $_POST["nombre"];
$descripcion = $_POST["descripcion"];
$ubicacion = $_POST["ubicacion"];
$horario = $_POST["horario"];
$web = $_POST["web"];

// Imagen opcional
$imagenEmpresaNombre = null;
if (isset($_POST["imagenBase64"]) && isset($_POST["nombreImagen"])) {
    $imagenBase64 = $_POST["imagenBase64"];
    $imagenEmpresaNombre = $_POST["nombreImagen"];

    $carpetaUploads = "uploads/";
    if (!file_exists($carpetaUploads)) {
        mkdir($carpetaUploads, 0777, true);
    }

    $imagenBinaria = base64_decode($imagenBase64);
    $rutaCompleta = $carpetaUploads . basename($imagenEmpresaNombre);
    if (!file_put_contents($rutaCompleta, $imagenBinaria)) {
        echo json_encode(["success" => false, "message" => "Error al guardar la imagen"]);
        exit;
    }
}

if ($imagenEmpresaNombre) {
    $sql = "INSERT INTO Empresas (idProfesionalFK, nombreEmpresa, descripcionEmpresa, ubicacionEmpresa, horarioEmpresa, webEmpresa, logoEmpresa)
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("issssss", $idProfesional, $nombre, $descripcion, $ubicacion, $horario, $web, $imagenEmpresaNombre);
} else {
    $sql = "INSERT INTO Empresas (idProfesionalFK, nombreEmpresa, descripcionEmpresa, ubicacionEmpresa, horarioEmpresa, webEmpresa)
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("isssss", $idProfesional, $nombre, $descripcion, $ubicacion, $horario, $web);
}

if ($stmt->execute()) {
    $idEmpresa = $stmt->insert_id;
    echo json_encode(["success" => true, "idEmpresa" => $idEmpresa]);
} else {
    echo json_encode(["success" => false, "message" => "Error al insertar empresa"]);
}

$stmt->close();
$conexion->close();
