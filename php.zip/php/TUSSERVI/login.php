<?php
header('Content-Type: application/json');

// Configuración de conexión
$host = 'localhost';
$usuario = 'root';
$contrasena = 'studium2023;';
$baseDeDatos = 'TusServiPrueba';

// Crear conexión
$conexion = new mysqli($host, $usuario, $contrasena, $baseDeDatos);

// Comprobar conexión
if ($conexion->connect_error) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Error de conexión a la base de datos: " . $conexion->connect_error
    ]);
    exit();
}

// Validar parámetros
if (empty($_POST['email']) || empty($_POST['password'])) {
    echo json_encode([
        "success" => false,
        "message" => "Debes enviar email y contraseña"
    ]);
    exit();
}

$email = trim($_POST['email']);
$password = $_POST['password'];

// Buscar el usuario
$stmt = $conexion->prepare("SELECT * FROM Usuarios WHERE emailUsuario = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$resultado = $stmt->get_result();

if ($usuario = $resultado->fetch_assoc()) {
    if (password_verify($password, $usuario['contraseñaUsuario'])) {
        // Datos base
        $response = [
            "success" => true,
            "usuario" => [
                "idUsuario" => $usuario["idUsuario"],
                "nombre" => $usuario["nombreUsuario"],
                "email" => $usuario["emailUsuario"],
                "telefono" => $usuario["telefonoUsuario"],
                "direccion" => $usuario["direccionUsuario"],
                "ciudad" => $usuario["ciudadUsuario"],
                "tipo" => $usuario["tipoUsuario"]
            ]
        ];

        // Si es profesional, obtener su idProfesional
        if ($usuario["tipoUsuario"] == "profesional") {
            $idUsuario = $usuario["idUsuario"];
            $stmtProfesional = $conexion->prepare("SELECT idProfesional FROM Profesionales WHERE idUsuarioFK = ?");
            $stmtProfesional->bind_param("i", $idUsuario);
            $stmtProfesional->execute();
            $resultadoPro = $stmtProfesional->get_result();
            if ($filaPro = $resultadoPro->fetch_assoc()) {
                $response["usuario"]["idProfesional"] = $filaPro["idProfesional"];
            }
            $stmtProfesional->close();
        }

        echo json_encode($response);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Contraseña incorrecta"
        ]);
    }
} else {
    echo json_encode([
        "success" => false,
        "message" => "Usuario no encontrado"
    ]);
}

$stmt->close();
$conexion->close();
?>
