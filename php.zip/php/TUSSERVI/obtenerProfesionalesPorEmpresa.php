<?php
header("Content-Type: application/json; charset=UTF-8");

// Conexión a la base de datos
$conexion = new mysqli("localhost", "root", "studium2023;", "TusServiPrueba");
$conexion->set_charset("utf8");

// Verificar conexión
if ($conexion->connect_error) {
    die(json_encode(["error" => "Error de conexión"]));
}

// Obtener idEmpresa desde GET
$idEmpresa = isset($_GET["idEmpresa"]) ? intval($_GET["idEmpresa"]) : 0;

if ($idEmpresa <= 0) {
    echo json_encode(["error" => "ID de empresa no válido"]);
    exit;
}

// Consulta: obtener los profesionales de la empresa junto con los datos del usuario
$sql = "SELECT 
            p.idProfesional, 
            u.idUsuario,  -- ⬅️ Añadido
            u.nombreUsuario AS nombre,
            p.categoriaProfesional AS categoria,
            u.fotoPerfilUsuario AS fotoPerfil
        FROM Profesionales p
        INNER JOIN Usuarios u ON p.idUsuarioFK = u.idUsuario
        INNER JOIN Empresas e ON e.idProfesionalFK = p.idProfesional
        WHERE e.idEmpresa = ?";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $idEmpresa);
$stmt->execute();
$resultado = $stmt->get_result();

$profesionales = [];

while ($fila = $resultado->fetch_assoc()) {
    $profesionales[] = [
        "idProfesional" => $fila["idProfesional"],
        "idUsuario" => $fila["idUsuario"], // ⬅️ Añadido al JSON
        "nombre" => $fila["nombre"],
        "categoria" => $fila["categoria"],
        "fotoPerfil" => "http://10.0.2.2/TUSSERVI/" . $fila["fotoPerfil"]
    ];
}

echo json_encode(["profesionales" => $profesionales]);

$stmt->close();
$conexion->close();
?>
