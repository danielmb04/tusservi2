<?php
include 'conexion.php';

$idUsuario = $_GET['idUsuario'];

// Buscar conversaciones donde el usuario esté implicado
$sql = "SELECT c.idConversacion, 
               IF(c.idUsuarioCliente = ?, c.idUsuarioProfesional, c.idUsuarioCliente) as idOtroUsuario,
               (SELECT nombreUsuario FROM usuarios WHERE idUsuario = idOtroUsuario) as nombreOtroUsuario,
               (SELECT contenido FROM mensajes WHERE idConversacion = c.idConversacion ORDER BY fechaEnvio DESC LIMIT 1) as ultimoMensaje
        FROM conversaciones c
        WHERE c.idUsuarioCliente = ? OR c.idUsuarioProfesional = ?
        ORDER BY (SELECT fechaEnvio FROM mensajes WHERE idConversacion = c.idConversacion ORDER BY fechaEnvio DESC LIMIT 1) DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iii", $idUsuario, $idUsuario, $idUsuario);
$stmt->execute();
$result = $stmt->get_result();

$datos = array();
while ($row = $result->fetch_assoc()) {
    $datos[] = $row;
}

echo json_encode($datos);
?>