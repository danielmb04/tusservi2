<?php
// Configuración de conexión
$host = 'localhost';
$db = 'TusServiPrueba';
$user = 'root';
$pass = 'studium2023;';

header('Content-Type: application/json');

// Comprobar si se recibió el idTarea
if (!isset($_POST['idTarea'])) {
    echo json_encode(['success' => false, 'message' => 'idTarea no recibido']);
    exit;
}

$idTarea = intval($_POST['idTarea']);

try {
    // Conexión a la base de datos
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Consulta para borrar la tarea
    $stmt = $pdo->prepare("DELETE FROM Tareas WHERE idTarea = ?");
    $stmt->execute([$idTarea]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Tarea eliminada correctamente']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Tarea no encontrada o ya eliminada']);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Error de conexión: ' . $e->getMessage()]);
}
?>
