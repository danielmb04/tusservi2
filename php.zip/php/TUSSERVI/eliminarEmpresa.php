<?php
header("Content-Type: application/json");
include("conexion.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $idEmpresa = isset($_POST['idEmpresa']) ? intval($_POST['idEmpresa']) : 0;

    if ($idEmpresa > 0) {
        $sql = "DELETE FROM Empresas WHERE idEmpresa = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $idEmpresa);

        if ($stmt->execute()) {
            echo json_encode(["success" => true, "message" => "Empresa eliminada correctamente."]);
        } else {
            echo json_encode(["success" => false, "message" => "Error al eliminar la empresa."]);
        }

        $stmt->close();
    } else {
        echo json_encode(["success" => false, "message" => "ID de empresa inválido."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Método no permitido."]);
}

$conexion->close();
?>
