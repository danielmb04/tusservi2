<?php
include 'conexion.php';

$idUsuario = $_POST['idUsuario'];

// Cambia la consulta con los nombres reales de columnas y tabla
$sql = "SELECT nombreUsuario, fotoPerfilUsuario FROM Usuarios WHERE idUsuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idUsuario);
$stmt->execute();
$result = $stmt->get_result();

if ($fila = $result->fetch_assoc()) {
    echo json_encode([
        'success' => true,
        'nombre' => $fila['nombreUsuario'],
        'foto' => $fila['fotoPerfilUsuario'] // URL completa o relativa a la imagen
    ]);
} else {
    echo json_encode(['success' => false, 'mensaje' => 'Usuario no encontrado']);
}
?>
