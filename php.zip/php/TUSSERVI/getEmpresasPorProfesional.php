<?php
include("conexion.php");

$idProfesional = $_GET['idProfesional'];

$response = array();
$sql = "SELECT 
            e.idEmpresa,
            e.nombreEmpresa,
            e.descripcionEmpresa,
            e.ubicacionEmpresa,
            e.horarioEmpresa,
            e.webEmpresa,
            e.logoEmpresa,
            p.categoriaProfesional,
            p.experienciaProfesional
        FROM empresas e
        INNER JOIN profesionales p ON e.idProfesionalFK = p.idProfesional
        WHERE e.idProfesionalFK = $idProfesional
        ORDER BY e.fechaRegistroEmpresa DESC";


$result = mysqli_query($conn, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    $empresas = array();
    while ($row = mysqli_fetch_assoc($result)) {
        // Reemplazar null o "null" por cadena vacía
        foreach ($row as $key => $value) {
    if ($value === null || strtolower($value) === "null") {
        // Si el campo es numérico (por nombre), pon 0, si no, pon ""
        if ($key === 'experienciaProfesional') {
            $row[$key] = 0;
        } else {
            $row[$key] = "";
        }
    }
}
        $empresas[] = $row;
    }
    $response['success'] = true;
    $response['empresas'] = $empresas;
} else {
    $response['success'] = false;
    $response['message'] = "No hay empresas.";
}

echo json_encode($response);
?>
