<?php
header('Content-Type: application/json');
include 'conexion.php'; // Tu conexión a BD

// Recoger parámetros POST
$idEmpresa = $_POST['idEmpresa'] ?? null;
$nombreEmpresa = $_POST['nombreEmpresa'] ?? null;
$descripcionEmpresa = $_POST['descripcionEmpresa'] ?? null;
$ubicacionEmpresa = $_POST['ubicacionEmpresa'] ?? null;
$horarioEmpresa = $_POST['horarioEmpresa'] ?? null;
$webEmpresa = $_POST['webEmpresa'] ?? null;
$logoBase64 = $_POST['logoEmpresa'] ?? null;

if (!$idEmpresa || !$nombreEmpresa) {
    echo json_encode(['success' => false, 'message' => 'Faltan datos obligatorios']);
    exit;
}

// Inicializamos variable para el campo logo
$logoPath = null;

// Procesar imagen base64 si llega
if ($logoBase64) {
    // Quitar el prefijo data:image/png;base64,
    if (preg_match('/^data:image\/(\w+);base64,/', $logoBase64, $type)) {
        $logoBase64 = substr($logoBase64, strpos($logoBase64, ',') + 1);
        $type = strtolower($type[1]); // png, jpg, jpeg, gif

        if (!in_array($type, ['jpg', 'jpeg', 'png', 'gif'])) {
            echo json_encode(['success' => false, 'message' => 'Formato de imagen no soportado']);
            exit;
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Datos de imagen no válidos']);
        exit;
    }

    $logoBase64 = str_replace(' ', '+', $logoBase64);
    $data = base64_decode($logoBase64);

    if ($data === false) {
        echo json_encode(['success' => false, 'message' => 'Error al decodificar imagen']);
        exit;
    }

    // Crear carpeta uploads si no existe
    $dir = 'uploads/';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    // Crear nombre único para la imagen
    $fileName = 'empresa_' . time() . '.' . $type;

    // Guardar imagen en servidor dentro de uploads/
    $fullPath = $dir . $fileName;

    if (file_put_contents($fullPath, $data) === false) {
        echo json_encode(['success' => false, 'message' => 'No se pudo guardar la imagen']);
        exit;
    }

    // Guardamos solo el nombre del archivo para la BD (sin carpeta)
    $logoPath = $fileName;
}

// Preparar consulta con o sin logo
if ($logoPath) {
    $sql = "UPDATE Empresas SET 
        nombreEmpresa = ?, 
        descripcionEmpresa = ?, 
        ubicacionEmpresa = ?, 
        horarioEmpresa = ?, 
        webEmpresa = ?, 
        logoEmpresa = ? 
        WHERE idEmpresa = ?";
    $params = [$nombreEmpresa, $descripcionEmpresa, $ubicacionEmpresa, $horarioEmpresa, $webEmpresa, $logoPath, $idEmpresa];
} else {
    $sql = "UPDATE Empresas SET 
        nombreEmpresa = ?, 
        descripcionEmpresa = ?, 
        ubicacionEmpresa = ?, 
        horarioEmpresa = ?, 
        webEmpresa = ? 
        WHERE idEmpresa = ?";
    $params = [$nombreEmpresa, $descripcionEmpresa, $ubicacionEmpresa, $horarioEmpresa, $webEmpresa, $idEmpresa];
}

// Preparar y ejecutar statement
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Error en la consulta: ' . $conn->error]);
    exit;
}

// Bind de parámetros dinámico
$types = str_repeat('s', count($params) - 1) . 'i'; // últimas es int idEmpresa
$stmt->bind_param($types, ...$params);

if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => 'Empresa actualizada',
        'logoPath' => $logoPath // <-- puede ser null, y está bien
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Error al actualizar empresa']);
}


$stmt->close();
$conn->close();
?>
