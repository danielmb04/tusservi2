<?php
header('Content-Type: application/json');
include 'conexion.php';  // Tu archivo de conexión a la base de datos

$idCliente = $_POST['idCliente'] ?? null;
$idProfesional = $_POST['idProfesional'] ?? null;

if (!$idCliente || !$idProfesional) {
    echo json_encode(['success' => false, 'message' => 'Faltan parámetros']);
    exit;
}

// Buscar conversación existente
$query = "SELECT idConversacion FROM conversaciones WHERE idUsuarioCliente = ? AND idUsuarioProfesional = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $idCliente, $idProfesional);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $idConversacion = $row['idConversacion'];
} else {
    // Crear nueva conversación
    $insert = "INSERT INTO conversaciones (idUsuarioCliente, idUsuarioProfesional) VALUES (?, ?)";
    $stmtInsert = $conn->prepare($insert);
    $stmtInsert->bind_param("ii", $idCliente, $idProfesional);
    if ($stmtInsert->execute()) {
        $idConversacion = $stmtInsert->insert_id;
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al crear conversación']);
        exit;
    }
}

echo json_encode(['success' => true, 'idConversacion' => $idConversacion]);
?>
