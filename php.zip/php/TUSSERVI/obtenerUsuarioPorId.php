<?php
header('Content-Type: application/json');

// Datos conexión a BD (ajusta según tu configuración)
$servername = "localhost";
$username = "root";
$password = "studium2023;";
$dbname = "TusServiPrueba";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Comprobar conexión
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Error de conexión a la base de datos"]);
    exit();
}

if (!isset($_GET['idUsuario'])) {
    http_response_code(400);
    echo json_encode(["error" => "Falta parámetro idUsuario"]);
    exit();
}

$idUsuario = intval($_GET['idUsuario']);

$sql = "SELECT nombreUsuario, fotoPerfilUsuario FROM usuarios WHERE idUsuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idUsuario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(["error" => "Usuario no encontrado"]);
    exit();
}

$user = $result->fetch_assoc();

echo json_encode($user);

$stmt->close();
$conn->close();
?>
