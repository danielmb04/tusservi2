<?php
header('Content-Type: application/json');

// Configuración de la conexión a la base de datos
$host = "localhost";
$usuario = "root";
$contrasena = "studium2023;";
$basedatos = "TusServiPrueba";

// Conectar a la base de datos
$conn = new mysqli($host, $usuario, $contrasena, $basedatos);

// Verificar conexión
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Error en la conexión: " . $conn->connect_error]);
    exit();
}

// Obtener los datos JSON recibidos
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(["success" => false, "message" => "No se recibieron datos JSON"]);
    exit();
}

// Validar campos necesarios
if (!isset($input['idServicio'], $input['tituloServicio'], $input['descripcionServicio'], $input['precioEstimadoServicio'])) {
    echo json_encode(["success" => false, "message" => "Faltan campos requeridos"]);
    exit();
}

$idServicio = intval($input['idServicio']);
$titulo = $conn->real_escape_string($input['tituloServicio']);
$descripcion = $conn->real_escape_string($input['descripcionServicio']);
$precio = floatval($input['precioEstimadoServicio']);

// Preparar la consulta de actualización
$sql = "UPDATE servicios SET tituloServicio='$titulo', descripcionServicio='$descripcion', precioEstimadoServicio=$precio WHERE idServicio=$idServicio";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => true, "message" => "Servicio actualizado correctamente"]);
} else {
    echo json_encode(["success" => false, "message" => "Error al actualizar: " . $conn->error]);
}

$conn->close();
?>
