<?php
header('Content-Type: application/json');

// Parámetros recibidos
$idTarea = $_POST['idTarea'] ?? null;
$descripcion = $_POST['descripcion'] ?? null;
$realizada = isset($_POST['realizada']) ? $_POST['realizada'] : null;
$horaInicio = $_POST['horaInicio'] ?? '00:00:00';
$horaFin = $_POST['horaFin'] ?? '00:00:00';

// Validación básica
if (!$idTarea || !$descripcion || $realizada === null) {
    echo json_encode(['success' => false, 'message' => 'Faltan parámetros.']);
    exit;
}

// Convertir realizada a booleano/entero para BD
$realizada = ($realizada === 'true' || $realizada == 1) ? 1 : 0;

// Conectar a la BD
$servername = "localhost";
$username = "root";
$password = "studium2023;";
$dbname = "TusServiPrueba";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Error conexión BD']);
    exit;
}

// Consulta preparada para evitar inyección SQL
$stmt = $conn->prepare("UPDATE Tareas SET descripcion = ?, realizada = ?, horaInicio = ?, horaFin = ? WHERE idTarea = ?");
$stmt->bind_param("sissi", $descripcion, $realizada, $horaInicio, $horaFin, $idTarea);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Tarea actualizada correctamente']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error al actualizar tarea']);
}

$stmt->close();
$conn->close();
?>
