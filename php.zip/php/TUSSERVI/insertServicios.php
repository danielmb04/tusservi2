<?php
header("Content-Type: application/json");
$conexion = new mysqli("localhost", "root", "studium2023;", "TusServiPrueba");
if ($conexion->connect_error) {
    echo json_encode(["success" => false, "message" => "Error de conexión"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$idEmpresa = $data["idEmpresa"];
$servicios = $data["servicios"];

$stmt = $conexion->prepare("INSERT INTO Servicios (idEmpresaFK, tituloServicio, descripcionServicio, precioEstimadoServicio)
                            VALUES (?, ?, ?, ?)");

foreach ($servicios as $servicio) {
    $titulo = $servicio["tituloServicio"];
    $descripcion = $servicio["descripcionServicio"];
    $precio = $servicio["precioEstimadoServicio"];

    $stmt->bind_param("issd", $idEmpresa, $titulo, $descripcion, $precio);
    $stmt->execute();
}

$stmt->close();
$conexion->close();

echo json_encode(["success" => true]);
