<?php
// Conexión a la base de datos (ajusta según tu config)
$host = "localhost";
$user = "root";
$password = "studium2023;";
$dbname = "TusServiPrueba";

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$emisor_id = $_POST['idEmisor'] ?? null;
$receptor_id = $_POST['idReceptor'] ?? null;
$tipo = $_POST['tipo']; // "imagen" o "video"

// Validar archivo subido
if (!isset($_FILES['archivo'])) {
    http_response_code(400);
    echo json_encode(["error" => "No se recibió archivo"]);
    exit;
}

$archivo = $_FILES['archivo'];
$nombreTmp = $archivo['tmp_name'];
$nombreOriginal = basename($archivo['name']);
$ext = strtolower(pathinfo($nombreOriginal, PATHINFO_EXTENSION));

// Validar extensión según tipo
$extPermitidasImagen = ['jpg', 'jpeg', 'png', 'gif'];
$extPermitidasVideo = ['mp4', 'avi', 'mov', 'mkv'];

if ($tipo === "imagen" && !in_array($ext, $extPermitidasImagen)) {
    http_response_code(400);
    echo json_encode(["error" => "Formato de imagen no permitido"]);
    exit;
}

if ($tipo === "video" && !in_array($ext, $extPermitidasVideo)) {
    http_response_code(400);
    echo json_encode(["error" => "Formato de video no permitido"]);
    exit;
}

// Carpeta uploads
$carpetaUploads = "uploads/";
if (!is_dir($carpetaUploads)) {
    mkdir($carpetaUploads, 0755, true);
}

// Crear nombre único para el archivo
$nombreArchivoNuevo = $tipo . "_". uniqid() . "." . $ext;
$rutaArchivo = $carpetaUploads . $nombreArchivoNuevo;

if (move_uploaded_file($nombreTmp, $rutaArchivo)) {
    // Guardar mensaje en la BD con la ruta del archivo como mensaje
    $mensaje = $rutaArchivo;

    $stmt = $conn->prepare("INSERT INTO mensajes (emisor_id, receptor_id, mensaje, tipo) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $emisor_id, $receptor_id, $mensaje, $tipo);
    if ($stmt->execute()) {
        echo json_encode(["success" => true, "ruta" => $rutaArchivo]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Error al guardar mensaje"]);
    }
    $stmt->close();
} else {
    http_response_code(500);
    echo json_encode(["error" => "Error al mover archivo"]);
}

$conn->close();
?>
