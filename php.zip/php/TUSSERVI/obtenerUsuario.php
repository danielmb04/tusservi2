<?php
include "conexion.php";

header('Content-Type: application/json');

$idUsuario = isset($_GET['idUsuario']) ? intval($_GET['idUsuario']) : 0;

if ($idUsuario <= 0) {
    echo json_encode([]);
    exit;
}

// Obtener tipo de usuario
$sqlTipo = "SELECT tipoUsuario FROM usuarios WHERE idUsuario = $idUsuario LIMIT 1";
$resultTipo = $conn->query($sqlTipo);

if ($resultTipo->num_rows == 0) {
    echo json_encode([]);
    exit;
}

$tipoUsuario = $resultTipo->fetch_assoc()['tipoUsuario'];

// Según tipo, buscar usuarios del tipo opuesto
if ($tipoUsuario == 'cliente') {
    $sql = "SELECT idUsuario, nombreUsuario, fotoPerfilUsuario FROM usuarios WHERE tipoUsuario = 'profesional'";
} elseif ($tipoUsuario == 'profesional') {
    $sql = "SELECT idUsuario, nombreUsuario, fotoPerfilUsuario FROM usuarios WHERE tipoUsuario = 'cliente'";
} else {
    echo json_encode([]);
    exit;
}

$result = $conn->query($sql);

$usuarios = [];

while ($row = $result->fetch_assoc()) {
    if (empty($row['fotoPerfilUsuario'])) {
        // Puedes asignar el nombre de una imagen genérica por defecto
        $row['fotoPerfilUsuario'] = "default_profile_image.jpg";
    }
    // No concatenes la URL aquí, solo deja el nombre del archivo
    $usuarios[] = $row;
}


echo json_encode($usuarios);
?>
