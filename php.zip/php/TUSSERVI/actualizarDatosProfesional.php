<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include 'conexion.php';

$data = json_decode(file_get_contents("php://input"), true);

if ($data) {
    $idProfesional = $data['idProfesional'] ?? null;

    if ($idProfesional === null) {
        echo json_encode(["error" => "Falta idProfesional"]);
        exit;
    }

    // Obtener idUsuario relacionado a este profesional y fotoPerfilProfesional actual
    $sql = "SELECT idUsuarioFK, fotoPerfilProfesional FROM Profesionales WHERE idProfesional = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idProfesional);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $idUsuario = $row['idUsuarioFK'];
        $fotoPerfilProfesionalActual = $row['fotoPerfilProfesional']; // para conservar si no envían nueva imagen
    } else {
        echo json_encode(["error" => "Profesional no encontrado"]);
        exit;
    }
    $stmt->close();

    // Datos tabla Usuarios (sin foto)
    $nombre = $data['nombreUsuario'] ?? null;
    $email = $data['emailUsuario'] ?? null;
    $contrasena = $data['contraseñaUsuario'] ?? null;
    $telefono = $data['telefonoUsuario'] ?? null;
    $direccion = $data['direccionUsuario'] ?? null;
    $ciudad = $data['ciudadUsuario'] ?? null;

    // Datos tabla Profesionales
    $categoria = $data['categoriaProfesional'] ?? null;
    $experiencia = isset($data['experienciaProfesional']) ? intval($data['experienciaProfesional']) : null;
    $fotoPerfilProfesional = $data['fotoPerfilProfesional'] ?? null; // base64 o null

    // Procesar imagen base64 (si viene)
    if (!empty($fotoPerfilProfesional) && $fotoPerfilProfesional !== "null") {
        if (preg_match('/^data:image\/(\w+);base64,/', $fotoPerfilProfesional, $type)) {
            $fotoPerfilProfesional = substr($fotoPerfilProfesional, strpos($fotoPerfilProfesional, ',') + 1);
            $tipo = strtolower($type[1]);
            if (!in_array($tipo, ['jpg', 'jpeg', 'png', 'gif'])) {
                echo json_encode(["error" => "Tipo de imagen no soportado"]);
                exit;
            }
        } else {
            $tipo = 'jpg';
        }

        $fotoPerfilDecodificada = base64_decode($fotoPerfilProfesional);

        if ($fotoPerfilDecodificada === false) {
            echo json_encode(["error" => "Base64 no válido"]);
            exit;
        }

        $carpetaUploads = "uploads/";
        if (!file_exists($carpetaUploads)) {
            mkdir($carpetaUploads, 0755, true);
        }

        $nombreArchivo = "perfilProfesional_" . uniqid() . "." . $tipo;
        $rutaArchivo = $carpetaUploads . $nombreArchivo;

        if (file_put_contents($rutaArchivo, $fotoPerfilDecodificada) === false) {
            echo json_encode(["error" => "No se pudo guardar la imagen"]);
            exit;
        }

        // Borrar la foto anterior si existe
        if ($fotoPerfilProfesionalActual && file_exists($carpetaUploads . $fotoPerfilProfesionalActual)) {
            unlink($carpetaUploads . $fotoPerfilProfesionalActual);
        }

        $fotoPerfilParaBD = $nombreArchivo;
    } else {
        $fotoPerfilParaBD = null; // no actualizar foto
    }

    // Actualizar Usuarios (sin foto)
    $sqlUsuarios = "UPDATE Usuarios SET nombreUsuario=?, emailUsuario=?, contraseñaUsuario=?, telefonoUsuario=?, direccionUsuario=?, ciudadUsuario=? WHERE idUsuario=?";
    $stmt1 = $conn->prepare($sqlUsuarios);
    $stmt1->bind_param("ssssssi", $nombre, $email, $contrasena, $telefono, $direccion, $ciudad, $idUsuario);
    $stmt1->execute();

    // Actualizar Profesionales (con foto si viene)
    if ($fotoPerfilParaBD !== null) {
        $sqlProfesionales = "UPDATE Profesionales SET categoriaProfesional=?, experienciaProfesional=?, fotoPerfilProfesional=? WHERE idProfesional=?";
        $stmt2 = $conn->prepare($sqlProfesionales);
        $stmt2->bind_param("sisi", $categoria, $experiencia, $fotoPerfilParaBD, $idProfesional);
    } else {
        $sqlProfesionales = "UPDATE Profesionales SET categoriaProfesional=?, experienciaProfesional=? WHERE idProfesional=?";
        $stmt2 = $conn->prepare($sqlProfesionales);
        $stmt2->bind_param("sii", $categoria, $experiencia, $idProfesional);
    }
    $stmt2->execute();

    echo json_encode(["success" => true]);

    $stmt1->close();
    $stmt2->close();
    $conn->close();
} else {
    echo json_encode(["error" => "No se recibieron datos"]);
}
