<?php
include "conexion.php";

$emisor_id = $_POST['emisor_id'];
$receptor_id = $_POST['receptor_id'];
$mensaje = $_POST['mensaje'];
$tipo = isset($_POST['tipo']) ? $_POST['tipo'] : 'texto'; // por defecto 'texto'

// Validar que el tipo sea uno de los permitidos
$tipos_permitidos = ['texto', 'imagen', 'video'];
if (!in_array($tipo, $tipos_permitidos)) {
    $tipo = 'texto';
}

$sql = "INSERT INTO mensajes (emisor_id, receptor_id, mensaje, tipo) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iiss", $emisor_id, $receptor_id, $mensaje, $tipo);

$response = [];

if ($stmt->execute()) {
    $response["success"] = true;
} else {
    $response["success"] = false;
    $response["error"] = $stmt->error;
}

echo json_encode($response);
?>
