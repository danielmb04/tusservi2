<?php
header('Content-Type: application/json');

include 'conexion.php'; // tu archivo de conexión a la DB

$idUsuario = $_POST['idUsuario'] ?? null;
$descripcion = $_POST['descripcion'] ?? '';
$fechaCreacion = $_POST['fechaCreacion'] ?? '';
$horaInicio = $_POST['horaInicio'] ?? '';
$horaFin = $_POST['horaFin'] ?? '';
$realizada = isset($_POST['realizada']) ? intval($_POST['realizada']) : 0;

if ($idUsuario && $descripcion && $fechaCreacion) {
    $stmt = $conn->prepare("INSERT INTO tareas (idUsuario, descripcion, realizada, fechaCreacion, horaInicio, horaFin) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isisss", $idUsuario, $descripcion, $realizada, $fechaCreacion, $horaInicio, $horaFin);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "idTarea" => $stmt->insert_id]);
    } else {
        echo json_encode(["success" => false, "error" => "Error al insertar tarea"]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false, "error" => "Faltan parámetros"]);
}

$conn->close();
?>
