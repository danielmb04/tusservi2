<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include 'conexion.php'; // archivo que conecta a tu BD

if (isset($_GET['idUsuario'])) {
    $idUsuario = intval($_GET['idUsuario']);

    $sql = "SELECT 
                nombreUsuario,
                emailUsuario,
                contraseñaUsuario,
                telefonoUsuario,
                direccionUsuario,
                ciudadUsuario,
                fotoPerfilUsuario
            FROM Usuarios 
            
            WHERE idUsuario = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idUsuario);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($fila = $resultado->fetch_assoc()) {
        echo json_encode($fila);
    } else {
        echo json_encode(["error" => "Cliente no encontrado"]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["error" => "Falta idUsuario"]);
}
?>
