// listar_tareas.php?idUsuario=1
include 'conexion.php';

$idUsuario = $_GET['idUsuario'];
$sql = "SELECT idTarea, descripcion, realizada FROM Tareas WHERE idUsuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idUsuario);
$stmt->execute();
$result = $stmt->get_result();
$tareas = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($tareas);
