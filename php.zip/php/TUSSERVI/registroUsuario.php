<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

// Conexión a la base de datos
$conexion = new mysqli("localhost", "root", "studium2023;", "TusServiPrueba");
if ($conexion->connect_error) {
    echo json_encode(["success" => false, "message" => "Error de conexión a la base de datos"]);
    exit;
}

// Obtener datos desde POST
$data = $_POST;

// Validar que existan los campos básicos
$camposObligatorios = ['nombreUsuario', 'emailUsuario', 'contraseñaUsuario', 'tipoUsuario'];
foreach ($camposObligatorios as $campo) {
    if (empty($data[$campo])) {
        echo json_encode(["success" => false, "message" => "Falta el campo: $campo"]);
        exit;
    }
}

// Datos comunes para todos los usuarios
$nombreUsuario = $conexion->real_escape_string($data['nombreUsuario']);
$emailUsuario = $conexion->real_escape_string($data['emailUsuario']);
$contraseñaHash = password_hash($data['contraseñaUsuario'], PASSWORD_DEFAULT);
$telefonoUsuario = isset($data['telefonoUsuario']) ? $conexion->real_escape_string($data['telefonoUsuario']) : null;
$direccionUsuario = isset($data['direccionUsuario']) ? $conexion->real_escape_string($data['direccionUsuario']) : null;
$ciudadUsuario = isset($data['ciudadUsuario']) ? $conexion->real_escape_string($data['ciudadUsuario']) : null;
$tipoUsuario = $conexion->real_escape_string($data['tipoUsuario']);

// Procesar foto de perfil del usuario (cliente o profesional)
$fotoPerfilUsuario = null;
if (isset($data['fotoPerfilUsuario'])) {
    $base64Usuario = $data['fotoPerfilUsuario'];
    $nombreArchivoUsuario = 'perfil_usuario_' . uniqid() . '.jpg';
    $directorioUsuario = 'uploads/';
    $rutaArchivoUsuario = $directorioUsuario . $nombreArchivoUsuario;

    if (!file_exists($directorioUsuario)) {
        mkdir($directorioUsuario, 0777, true);
    }

    $base64Usuario = preg_replace('#^data:image/\w+;base64,#i', '', $base64Usuario);
    $base64Usuario = str_replace(' ', '+', $base64Usuario);

    if (!file_put_contents($rutaArchivoUsuario, base64_decode($base64Usuario))) {
        echo json_encode(["success" => false, "message" => "Error al guardar la imagen del usuario"]);
        exit;
    }

    $fotoPerfilUsuario = $conexion->real_escape_string($rutaArchivoUsuario);
}

// Insertar en Usuarios
$sqlUsuario = "INSERT INTO Usuarios (nombreUsuario, emailUsuario, contraseñaUsuario, telefonoUsuario, direccionUsuario, ciudadUsuario, tipoUsuario, fotoPerfilUsuario)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conexion->prepare($sqlUsuario);
$stmt->bind_param("ssssssss", $nombreUsuario, $emailUsuario, $contraseñaHash, $telefonoUsuario, $direccionUsuario, $ciudadUsuario, $tipoUsuario, $fotoPerfilUsuario);

if (!$stmt->execute()) {
    echo json_encode(["success" => false, "message" => "Error al registrar usuario: " . $stmt->error]);
    exit;
}

$idUsuario = $stmt->insert_id;
$stmt->close();

// Si es profesional, insertar datos extra en Profesionales
if ($tipoUsuario === 'profesional') {
    $camposProfesional = ['categoriaProfesional','experienciaProfesional', 'fotoPerfilProfesional'];
    foreach ($camposProfesional as $campo) {
        if (!isset($data[$campo])) {
            echo json_encode(["success" => false, "message" => "Falta el campo de profesional: $campo"]);
            exit;
        }
    }

    $categoria = $conexion->real_escape_string($data['categoriaProfesional']);
    $experiencia = intval($data['experienciaProfesional']);
   
    
    $base64 = $data['fotoPerfilProfesional'];
    $nombreArchivo = 'perfil_' . uniqid() . '.jpg';
    $directorio = 'uploads/';
    $rutaArchivo = $directorio . $nombreArchivo;

    if (!file_exists($directorio)) {
        mkdir($directorio, 0777, true);
    }

    $base64 = preg_replace('#^data:image/\w+;base64,#i', '', $base64);
    $base64 = str_replace(' ', '+', $base64);

    if (!file_put_contents($rutaArchivo, base64_decode($base64))) {
        echo json_encode(["success" => false, "message" => "Error al guardar la imagen en el servidor"]);
        exit;
    }

    $fotoPerfil = $conexion->real_escape_string($nombreArchivo);


$sqlProfesional = "INSERT INTO Profesionales (idUsuarioFK, categoriaProfesional, experienciaProfesional, fotoPerfilProfesional)
                   VALUES (?, ?, ?, ?)";
$stmt = $conexion->prepare($sqlProfesional);
$stmt->bind_param("isis", $idUsuario, $categoria, $experiencia, $fotoPerfil);


    if (!$stmt->execute()) {
        echo json_encode(["success" => false, "message" => "Error al registrar profesional: " . $stmt->error]);
        exit;
    }
    $stmt->close();
}

echo json_encode(["success" => true, "message" => "Usuario registrado correctamente"]);
$conexion->close();
?>
