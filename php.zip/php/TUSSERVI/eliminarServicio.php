<?php
header("Content-Type: application/json");
include("conexion.php");

$datos = json_decode(file_get_contents("php://input"), true);

if (isset($datos["idServicio"])) {
    $idServicio = $datos["idServicio"];

    $query = "DELETE FROM Servicios WHERE idServicio = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $idServicio);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Servicio eliminado"]);
    } else {
        echo json_encode(["success" => false, "message" => "Error al eliminar"]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false, "message" => "ID no recibido"]);
}

$conn->close();
?>
