<?php
header("Content-Type: application/json");
include("conexion.php");

// Leer el JSON raw del cuerpo de la petición
$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, true); // true para obtener array asociativo

$idUsuario = $input['idUsuario'] ?? null;
$fecha = $input['fecha'] ?? null;

if (!$idUsuario || !$fecha) {
    echo json_encode(["error" => "Faltan parámetros: idUsuario y/o fecha"]);
    exit;
}

$sql = "SELECT * FROM Tareas WHERE idUsuario = ? AND DATE(fechaCreacion) = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(["error" => "Error al preparar la consulta: " . $conn->error]);
    exit;
}

$stmt->bind_param("is", $idUsuario, $fecha);
$stmt->execute();
$resultado = $stmt->get_result();

$tareas = [];
while ($fila = $resultado->fetch_assoc()) {
    $tareas[] = $fila;
}

echo json_encode(["tareas" => $tareas]);

$stmt->close();
$conn->close();
?>
